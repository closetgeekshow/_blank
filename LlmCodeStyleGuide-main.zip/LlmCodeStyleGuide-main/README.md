# LllCodeStyleGuide
General guidance rules to give Cody and other LLMs 
